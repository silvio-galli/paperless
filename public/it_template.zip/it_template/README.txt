# TODO: da completare

ISTRUZIONI PER IMPORTARE NUOVI PRODOTTI CON FILE .csv

 1. DOWNLOAD CARTELLA
 2. CONTENUTO DELLA CARTELLA
 3. COMPILAZIONE FILE .ods/.xls


 
 1. DOWNLOAD CARTELLA

 Assicurarsi di aver scaricato la cartella corrispondente alla lingua utilizzata
 nell'applicazione: per la lingua italiana, il file di riferimento è
 "it_template.zip".
 L'utilizzo dei file inglesi dall'applicazione in italiano genererà un errore
 e impedirà la corretta importazione dei prodotti nel database.



 2. CONTENUTO DELLA CARTELLA
 
 La cartella contiene 3 modelli in formato diverso:
 un file .csv, uno .ods (foglio di calcolo Open Document Format) ed uno .xls.

 Il consiglio è quello di compilare il file .ods o .xls, salvarlo in formato
 .csv sul proprio pc e usare questo file per l'importazione dei prodotti nel
 database.
 La compilazione diretta del file .csv è molto più scomoda e complicata.


 
 3. COMPILAZIONE FILE .ods/.xls
 
